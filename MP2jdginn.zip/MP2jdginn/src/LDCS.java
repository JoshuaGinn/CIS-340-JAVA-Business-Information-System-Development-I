// MP2, Joshua Ginn, jdginn, CIS340 Online


import java.util.ArrayList;
import java.util.Scanner;

public class LDCS {

	
	// Creates new scanner object.
	public Scanner scanner = new Scanner(System.in);
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// Creates instance of displayMenu() and invokes method.	
		LDCS myLibrary = new LDCS();
		myLibrary.displayMenu();
				
	}

	
	// Declares new arraylist of Book objects.
	public ArrayList<Device> deviceList = new ArrayList<>();
		
	
	// Asks details for device being logged into the system.
	public void addDevice() {
			
		System.out.println("\n\n\n\n\n\n\n\t\t\tLibrary Device Checkout System - Add New Device\n\n");
			
		String name;
		String sku;
			
		System.out.printf("Sku: ");
		sku = scanner.nextLine();
		System.out.printf("Name: ");
		name = scanner.nextLine();
			

		Device tmpDevice = new Device(sku, name);
		deviceList.add(tmpDevice);
			
			
		System.out.printf("\nAdded %s to the Catalog.\n", name);
		System.out.printf("Press Enter to continue...");	
		scanner.nextLine();	
		System.out.println("\n\n\n\n\n");
	}

			
	// Prints all checked out Devices and User inputs which device they what available set to true.		
	public void checkIn() {
		System.out.println("\n\n\n\n\n\n\n\t\t\tLibrary Device Checkout System - Check In Device\n\n");
		
		System.out.println("Checked Out Devices\n");
		System.out.println("  #   SKU       Name");
		int counter = 1;
		
		for (Device d : deviceList) {
			
				
			boolean available = d.getAvailable();
			
			if (available == false) {
			System.out.printf("  %-2s  ",counter);
			d.printInformation();
				
			}
			counter++;	
			
		}
			
		System.out.printf("\nEnter device number: ");
		int selectedDevice = Integer.parseInt(scanner.nextLine());
		
		selectedDevice=selectedDevice-1;
		
		deviceList.get(selectedDevice).setAvailable(true);
		
		System.out.println("Device Checked In.");
		
		System.out.println("\nPress Enter to continue...");
		scanner.nextLine();// Stops Program for User
		System.out.println("\n\n\n\n\n");
		
	}
		
		
		
	// Prints all available = true devices, and user inputs which device should be set to not Available.	
	public void checkOut() {
		
		System.out.println("\n\n\n\n\n\n\n\t\t\tLibrary Device Checkout System - Check Out Device\n\n");
		
		System.out.println("Available Devices\n");
		System.out.println("  #   SKU       Name");
		int counter = 1;
		
		for (Device d : deviceList) {
			
				
			boolean available = d.getAvailable();
			
			if (available == true) {
			System.out.printf("  %-2s  ",counter);
			d.printInformation();
				
			}
			counter++;	
			
		}
			
		System.out.printf("\nEnter device number: ");
		int selectedDevice = Integer.parseInt(scanner.nextLine());
		
		selectedDevice=selectedDevice-1;
		
		deviceList.get(selectedDevice).setAvailable(false);
		
		System.out.println("Device Checked Out.");
		
		System.out.println("\nPress Enter to continue...");
		scanner.nextLine();// Stops Program for User
		System.out.println("\n\n\n\n\n");
	}
	
	
	// Prints Option "1"- Prints all devices name, Sku, and availabilty.
	public void displayList() {
		
		System.out.println("\n\n\n\n\n\n\n\t\t\tLibrary Device Checkout System - List\n\n");
		System.out.println("  #  SKU       Name");
		int counter = 1;
		for (Device d : deviceList) {
			
			System.out.printf("  %-2s ",counter);
			d.printInformationTitle();
			counter++;
			
		}
		System.out.printf("\n\nPress Enter to Continue...");
		scanner.nextLine();// Stops Program for User
		System.out.println("\n\n\n");
	}
	
	
	// Prints all options for User to input what method the would like invoked.
	public void displayMenu() {
		
		loadInventory(); // Updates with 6 stock devices.
		
		int selection;
		do {
		
			System.out.println("\t\t\tLibrary Device Checkout System\n\n");
		
			System.out.printf( "1. List Devices by Title\n2. Add New Devices\n3. Edit Device Information\n4. Search by Device Name\n5. Check Out Devices\n6. Check In Devices\n7. Exit\n\n\n");
			System.out.printf("Select menu options 1-7: ");
		
			 selection = Integer.parseInt(scanner.nextLine());
		
			switch (selection) {
			case 1: 
				displayList();
				break;
			case 2:
				addDevice();
				break;
			case 3:
				editDevice();
				break;
			case 4:
				searchList();
				break;
			case 5:
				checkOut();
				break;
			case 6:
				checkIn();
				break;
			case 7:
				System.out.printf("Goodbye!");
				System.exit(0);
				break;
			default:
			
			}
		}while(selection >= 1 && selection <= 6);
		
		System.out.printf("Goodbye");
	}	
	
	
	// List of devices are printed to console and user selects- and re-inputs Devices name and sku.
	public void editDevice() {
		System.out.println("\n\n\n\n\n\n\n\t\t\tLibrary Device Checkout System - List\n\n");
		System.out.println("  #  SKU       Name");
		int counter = 1;
		for (Device d : deviceList) {
			
			System.out.printf("  %-2s ",counter);
			d.printInformation();
			counter++;
			
		}
		
		System.out.printf("\n\n\nEnter Device number to edit (1-%s): ", (counter-1));
		int selectedDevice = Integer.parseInt(scanner.nextLine());
		
		selectedDevice=selectedDevice-1;
		System.out.printf("Sku: ");
		deviceList.get(selectedDevice).setSku(scanner.nextLine());
		System.out.printf("Name: ");
		deviceList.get(selectedDevice).setName(scanner.nextLine());
	}
	
	
	
	// creates 6 sample items (Device Objects) to show functionality.
	// New Devices are set to available(true) by default, 3 of 6 are set to false to show function.
	public void loadInventory() {
		Device tmpDevice = new Device("6757A", "Apple 9.7-inch iPad Pro");
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("93P51B", "Amazon Kindle Fire Kids Edition");
		tmpDevice.setAvailable(false);
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("10N8C", "LeapFrop Epic Learning Tablet");
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("DE432", "Apple 13-inch Macbook Air");
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("85U20", "HP Envy 8 Note");
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("SV83Q", "Amazon Echo Smart Assistant");
		tmpDevice.setAvailable(false);
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("LM45A", "Apple 13.3-inch Macbook Pro");
		tmpDevice.setAvailable(false);
		deviceList.add(tmpDevice);
		
		tmpDevice = new Device("F893W", "Amazon Fire HD 8  Plus Tablet");
		tmpDevice.setAvailable(false);
		deviceList.add(tmpDevice);	
		
	}
	
	
	
	// Uses .contains method to print only items that contain part of String inside name list.
	public void searchList() {
		System.out.println("\n\n\n\n\n\n\n\t\t\tLibrary Device Checkout System - Search\n\n");
		System.out.printf("Enter Device to search for: ");
		String keyword = scanner.nextLine();
		keyword = keyword.toLowerCase();
		
		System.out.printf("\nListings for '%s'\n", keyword);
		System.out.println("  # SKU       Name");
		int counter = 1;
		
		for (Device d : deviceList) {
			
			String name = d.getName().toLowerCase(); 
			if (name.contains(keyword)) {
			System.out.printf("  %-2s",counter);
			d.printInformation();
			
			}
			counter++;	
		}
		
		System.out.printf("\n\nPress Enter to Continue...");
		scanner.nextLine();// Stops Program for User
		System.out.println("\n\n\n\n\n");
	}
		
		
}
