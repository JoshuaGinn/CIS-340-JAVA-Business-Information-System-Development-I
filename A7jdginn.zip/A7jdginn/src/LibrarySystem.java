// A7, Joshua Ginn, jdginn, CIS340 Online

import java.util.ArrayList;
import java.util.Scanner;

public class LibrarySystem {

	// Creates new scanner object.
	public Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Creates instance of loadLibrarySystem and invokes method.
		LibrarySystem myLibrary = new LibrarySystem();
		myLibrary.loadLibrarySystem();
		
		
	}
	
	// Declares new arraylist of Book objects.
	public ArrayList<Book> bookList = new ArrayList<>();
	
	// Prompts user to insert title and year for each book
	public void addBook(int iterations) {
		
		System.out.println();
		
		
		// for the number of books, a new Book object is created and added to the bookLst Array.
		for (int i = 0; i < iterations; i++) {
			
			String title;
			int year;
		
			System.out.printf("Enter Book title: ");
			title = (scanner.nextLine());
			
			System.out.printf("Enter Book Year: ");
			year = Integer.parseInt(scanner.nextLine());
			
			Book tmpBook = new Book(title, year);
			bookList.add(tmpBook);
		
			System.out.printf("Title '%s' added to the library.\n", title);
			}
		
		// prompts user that they have finsihed adding books.
		System.out.printf("\nAdding books complete. Press enter to continue.");	
		String next = scanner.nextLine();
		}
		
	
	
	// Failed attempted at utilizing setters constraints/ restrictions/.
	
	//  Could type any year into console with no restriction
	
//	public void addBook(int iterations) {
//	
//	
//		for (int i = 0; i < iterations; i++) {
//		
//			Book tmpBook = new Book();
//					
//	
//			System.out.printf("Enter Book title: ");
//			tmpBook.setTitle(scanner.nextLine());
//		
//			System.out.printf("Enter Book Year: ");
//			tmpBook.setYear(Integer.parseInt(scanner.nextLine()));
//		
//		
//			bookList.add(tmpBook);}
//	}	
	

	// For each Book object in bookList, getters are invoked for title and year.
	public void diplayBookList() {
		System.out.printf("Title                                              Year");
		for(Book b : bookList) {
			System.out.printf("\n%-50s %-4s", b.getTitle(), b.getYear());
		}
	}
	
	// Greats user with title of program.
	public void displayHeader() {
		System.out.println("\t\t\tNew Library System\n\n");
	}
	
	// Asks user for number of books being added, and invokes methods in order.
	public void loadLibrarySystem(){
		
		displayHeader();
		
		System.out.printf("How many new books do you want to add to the library? ");
		
		addBook(Integer.parseInt(scanner.nextLine()));
		
		System.out.printf("\n\n\n\n"); // Clears console
		
		displayHeader();
		
		diplayBookList();
	}
	

}
