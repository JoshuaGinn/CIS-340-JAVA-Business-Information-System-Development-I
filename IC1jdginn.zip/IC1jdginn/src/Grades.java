// E1, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class Grades {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String studentName = "";
		int score = 0;
		char grade = 'O';
		String feedback = "";
		
		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
		
		//Prompts user to enter name as a string.
		System.out.println("\t\t\tLetter Grade Calculator");
		System.out.printf("What's your name? ");
		studentName = scanner.nextLine();
		
		//Prompts user to input score as an integer.
		System.out.printf("Enter an integer score for %s: ", studentName);
		score = scanner.nextInt();
		
		
		// Stores letter grade as a character from integer score.
		if (score >= 90)
		{
			grade = 'A';
		}
		else if (score >=80 && score < 90)
		{
			grade = 'B';
		}
		else if (score >= 70 && score < 80)
		{
			grade = 'C';
		}
		else if (score >= 60 && score < 70)
		{
			grade = 'D';
		}
		else if(score < 60)
		{
			grade = 'F';
		}
		
		System.out.printf("The grade for the class is %c. ", grade);
		
		
		// Informs User if they passed or failed.
		if (grade != 'F')
		{
			System.out.printf("You passed. ");
		}
		else 
		{
			System.out.printf("You failed. ");
		}
		
		
		
		// Prints corresponding motivational exclamation.
		if (grade == 'A')
		{
			System.out.println("Awesome! ");
		}
		else if (grade == 'B')
		{
			System.out.println("Beautiful! ");
		}
		else if (grade == 'C')
		{
			System.out.println("Completed! ");
		}
		else if (grade == 'D')
		{
			System.out.println("Done! ");
		}
		else if (grade == 'F')
		{
			System.out.println("Forget it happened! ");
		}
		
		
		
		System.out.println("\n***Feedback using if statement.***");
		//Provides feedback from grade variable.
		if (grade == 'A')
		{
			System.out.printf("Keep doing what you're doing.");
		}
		if (grade == 'B')
		{
			System.out.printf("Keep doing what you're doing.");
		}
		if (grade == 'C')
		{
			System.out.printf("Do better next semester.");
		}
		if (grade == 'D')
		{
			System.out.printf("Do better next semester.");
		}
		
		
		System.out.println("\n\n***Feedback using switch structure.***");
		
		// Assigns feedback variable a string based from letter grade received.
		switch ( grade ) {	
		case 'A':
			feedback = "Keep doing what you are doing.";
			break;
		case 'B':
			feedback = "Keep doing what you are doing.";
			break;
		case 'C':
		case 'D':
		case 'F':
			feedback = "Do better next semester.";
			break;
		default:
			feedback = "Error. Unkown grade.";
			break;
		}
		
		
		// Assigns score range the first digit of the users score, and prints 
		// the corresponding score range.
		switch (score / 10) {	
		case 10:
			System.out.printf("Your score is a perfect 100!");
			break;
		case 9:
			System.out.printf("Your score is in the 90s! ");
			break;
		case 8:
			System.out.printf("Your score is in the 80s! ");
			break;
		case 7:
			System.out.printf("Your score is in the 70s! ");
			break;
		case 6:
			System.out.printf("Your score is in the 60s! ");
			break;
		default:
			System.out.printf("Your score could be improved upon. ");
			break;	
		}	
		
		// Prints feedback 
		System.out.printf(feedback);
		
		scanner.close();
	}

}
