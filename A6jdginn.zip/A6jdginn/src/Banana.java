// A6, Joshua Ginn, jdginn, CIS340 Online


public class Banana {

	
	// Declares variables related to apple capacity
	private int peelThickness;
	private double percentLeft;
	private double length;
	
	
	
	// sets percentLeft to 100
	public Banana() {
		
		double percentLeft = 100.0;
		this.percentLeft = percentLeft;
	}
	
	
	
	// when passed a double. banana is invoked by length is also assigned to this.length
	public Banana(double length) {
		
		double percentLeft = 100.0;
		this.percentLeft = percentLeft;
		this.length = length;
		
	}
	
	
	
	
	// set/get returns and decalres this.length.
	public double getLength() {
		
		return length;
	}
	
	public void setLength(double value) {
		
		this.length = value;
	}
	
	
	
	// returns/declares this.peelthickness
	public int getPeelThickness() {
		
		return peelThickness;
	}
	
	public void setPeelThickness(int value) {
		this.peelThickness = value;
	}
	
	
	// returns percentage of banana remaining
	public double getPercentLeft() {
		
		return percentLeft;
	}
	
	
	// subtracts users inputed eaten amount by percentleft of apple.
	public void eat(double eatenAmount) {
		
		percentLeft = percentLeft - eatenAmount; 
		
		
	}
}
