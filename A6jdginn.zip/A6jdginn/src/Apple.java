// A6, Joshua Ginn, jdginn, CIS340 Online


public class Apple {
	
	
	// Declares variables related to apple capacity
	private int peelThickness;
	private double percentLeft;
	private double radius;
	
	// sets this.percentLeft to 100 to represent 100 percent points.
	public Apple() {
		
		double percentLeft = 100.0;
		this.percentLeft = percentLeft;
	}
	
	// sets param to this.radius
	public Apple(double radius) {
		
		double percentLeft = 100.0;
		this.percentLeft = percentLeft;
		this.radius = radius;
		
	}
	
	// get/set for peel thickness.
	public int getPeelThickness() {
		
		return peelThickness;
	}
	public void setPeelThickness(int value) {
		this.peelThickness = value;
	}
	
	// returns percent of fruit left.
	public double getPercentLeft() {
		
		return percentLeft;
	}
	
	// (set/get) declares and returns radius of apple
	public double getRadius() {
		
		return radius;
	}
	
	public void setRadius(double value) {
		
		this.radius = value;
	}
	
	
	// subtracts users inputed eaten amount by percentleft of apple.
	public void eat(double eatenAmount) {
		
		percentLeft = percentLeft - eatenAmount; 
		
		
	}
	
	
}
