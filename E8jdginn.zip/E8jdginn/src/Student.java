// E8, Joshua Ginn, jdginn, CIS340 Online


public class Student {

	
	//Declares private varables for passing/storing as parmeters.
	private static int studentCount;
	private String name;
	private String id;
	
	// constructor that sets parameter as name var
	public Student(String name) {
		
		this.name = name;
		
		studentCount++;
		
		System.out.printf("\nA new student, %s, has been created.", name);
		System.out.printf("\nThere are now %d students in the system.", studentCount);
	}
	
	// constructor that sets parameters as name and id vars
	public Student (String name, String id) {
		
		this.name = name;
		this.id = id; 
		
		studentCount++;
		
		System.out.printf("\nA new student, "+ name + ", with ID #" + id + " has been created.");
		System.out.printf("\nThere are now %d students in the system.", studentCount);
	}
	
	
	// Methods to get and set name var (returns name and sets new name)
	public String getName() {
		
		return name;
	}
	
	public void setName(String name) {
		
		this.name = name;
	}
	
	
	
	// Get and Sets id varaible ( returns id and sets new id)
	public String getId() {
		
		return id;
	}
	
	public void setId(String id) {
		
		this.id = id;
	}
	
	
	// returns number of student in system.
	public static int getStudentCount() {
		
		return studentCount;
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
}
