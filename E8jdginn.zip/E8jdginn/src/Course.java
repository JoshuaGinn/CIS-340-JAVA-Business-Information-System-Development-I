// E8, Joshua Ginn, jdginn, CIS340 Online

public class Course {


	private String coursePrefix;
	
	// getter method for field
	public String getCoursePrefix() {
		
		return coursePrefix.toUpperCase();
	}
		
	//setter method  for the field
	public void setCoursePrefix(String coursePrefix) {
		// THIS keyword is to reference an object
		this.coursePrefix = coursePrefix;
	}
	
	
	
	
	// Declares and creates get and set methods for course numbers.
	private int courseNumber;

	public int getCourseNumber() {
		
		return courseNumber;
	}
	
	public void setCourseNumber(int courseNumber) {
		
		this.courseNumber = courseNumber;
	}
	
	
	
	
	
	// Declares and creates get and set methods for college name.
	private static String collegeName;

	public static String getCollegeName() {
		
		return collegeName;
	}
	
	public void setCollegeName(String collegeName) {
		
		Course.collegeName = collegeName;
	}
	
	
	
	// Declares and creates get methods for (returns) class Average.
	private double classAverage = 0.0;
	
	public double getClassAverage() {
		
		return classAverage;
	}
	
	
	
	// Prints Confirmation message to user, restating the course + prefix added.
	public void displayMessage() {
		
		System.out.printf("Welcome to the grade book for %s %d!", getCoursePrefix(), getCourseNumber());
		
	}
	
	
	
}
