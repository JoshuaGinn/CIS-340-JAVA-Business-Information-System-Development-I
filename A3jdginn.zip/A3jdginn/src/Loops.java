// A3, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Imports scanner tool
				Scanner scanner = new Scanner(System.in);
		
		// Prints even numbers 1-19 (Loops 10 times)
		System .out.println("Part 1 - Odd Numbers");
		for (int i=1; i<20; i=i+2) {
			System.out.print(i + " ");
		}
		
		
		/* Prints "counter" variable if it has no remainder after being
		divided by two. Loops 20 times */
		System .out.println("\n\nPart 2 - Even Numbers");
		int counter = 1;
		while (counter <= 20)
		{
			if(counter % 2 == 0)
			System.out.printf(counter + " ");
			
			counter++;
		} //end while)
		
		
		// Receives int input and multiplies counter variable by runningSum varaiable
		// after counter hits zero, total factorial is printed.
		System .out.println("\n\nPart 3 - factorial");
		System .out.printf("Enter a number for the factorial: ");
		counter = Integer.parseInt(scanner.nextLine());
		int runningSum = 1;
		while (counter > 0)
		{ 
			runningSum = runningSum * counter;
			counter--;
		}
		System.out.printf( "The factorial is %2d", runningSum);
	
		
		// Prints ten loops, Number of i is printed as "*"
		System.out.println("\n\nPart 4 - Triangle");
		for (int i = 10; i > 0 ; i--) {
			
			for (int j = 0; j < i; j++) {	 
				System.out.printf("*");
			}
			System.out.println();
		}//End for
		
		
		// Pressing Enter will execute next section. 
		System.out.println("\nPress Enter for next page...");
		String nextPage = scanner.nextLine();
		System.out.println(nextPage);
		
		
		// Collects 2 int scores for 3 students each and prints average score.
		System.out.println("Part 5 - Average calculator\n");
		System.out.println("This program will ask you to enter 2 scores for 3 students.\n");
		
		int numberOfScores = 0;
		int runningScore = 0;
		
		for (int i=1; i<4; i++) {
			
			for (int j=1; j<3; j++) {
				System.out.printf("Student %2d, score %2d: ", i, j);
				 
				int score = 0;
				score = Integer.parseInt(scanner.nextLine());
				
				runningScore = runningScore + score;
				
				numberOfScores++;
			}
		}
		float scoreAverage =  (float) runningScore/numberOfScores;	
		System.out.printf("\nThe average of all scores is %.2f\n", scoreAverage);
		
		
		
		// Pressing Enter will execute next section. 
		System.out.println("\nPress Enter for next page...");
		String nextPageTwo = scanner.nextLine();
		System.out.println(nextPageTwo);
		
		
		
		// Prints multiplication tables using int i and int j as products.
		System.out.println("Part 6 - Multiplication Table");
		for (int i=5 ; i <= 10 ; i++ )
		{
			for (int j = 10 ; j <= 50 ; j = j+10 ) {
				System.out.printf("\n%2d * %2d = %4d", i, j, i*j);
			}
			System.out.println();
			
		} //end for
		
		
		
		scanner.close();
	}

	
	
}
