// E8, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;
import java.util.ArrayList;

public class CourseApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner = new Scanner(System.in);
		
		// Declares and instantiates two course objects
		Course courseOne;
		Course courseTwo;
		
		courseOne = new Course();
		courseTwo = new Course();
		
		
		// accepts input from user and use used as parameter for set course/number.
		System.out.printf("Please enter the first course prefix: ");
		courseOne.setCoursePrefix(scanner.nextLine());
		
		System.out.printf("Please enter the course number: ");
		courseOne.setCourseNumber(Integer.parseInt(scanner.nextLine()));
		
		
		
		// param for CollegeName as string "ASU"
		courseOne.setCollegeName("ASU");
		
		
		
		// courseOne.setClassAverage();  cannot set > Class Average is read-only.
		
		
		// prints the course number and prefix back to the user.
		System.out.printf("\nA new Course was created for %s %d at %s.\n", courseOne.getCoursePrefix(), courseOne.getCourseNumber(), Course.getCollegeName());
		
		
		//invokes display message method from course Class.
		courseOne.displayMessage();
		
		String sc = scanner.nextLine();
		
		
		
		// accepts input from user and use used as parameter for set course/number.
		System.out.printf("\n\nPlease enter the second course prefix: ");
		courseTwo.setCoursePrefix(scanner.nextLine());
		
		System.out.printf("Please enter the course number: ");
		courseTwo.setCourseNumber(Integer.parseInt(scanner.nextLine()));
		
		
		
		// param for CollegeName as string "ASU"
		courseTwo.setCollegeName("ASU");
		
		
		
		// prints the course number and prefix back to the user.
		System.out.printf("\nA new Course was created for %s %d at %s.\n", courseTwo.getCoursePrefix(), courseTwo.getCourseNumber(), Course.getCollegeName());
	
		
		//invokes display message method from course Class.	
		courseTwo.displayMessage();
		
		// invokes loadStudent method
		loadStudents();
	}

	
	
	// Allows user to input name and id variable while continueLoop is false.
	// Prints all names and ids in two columns back to the console for user.
	private static void loadStudents() {
		
		Scanner scanner = new Scanner(System.in);
		
		//declares and initializes ArrayList 
		ArrayList<Student> studentRoster;
		studentRoster = new ArrayList<>();

		// Declares local variables for storing student names and id
		// do loop will loop while coninueLoop is false.
		boolean continueLoop = false;
		String name;
		String id;
		
		System.out.printf("\n\nAdding students to the ArrayList...");
		
		do {
			continueLoop = false;
			System.out.printf("\nEnter Student Name: ");
			name = scanner.nextLine();
			System.out.printf("Enter Student ID: ");
			id = scanner.nextLine();
			
			// creates and adds tempStudent Student to studentRoster.
			Student tmpStudent = new Student(name, id);
			studentRoster.add(tmpStudent);
			
			// Prompts user to input y to continue the loop, or any other key for exit loop.
			System.out.printf("\n\nDo you want to enter information for another student?\n");
			System.out.printf(" Enter 'Y' for Yes. Any other key for No. ");
			String input = scanner.nextLine();
			
			// do loop will loop while coninueLoop is false.
			if (input.equalsIgnoreCase("y")) {
				continueLoop = true;
			}
		} while (continueLoop == true);
		
		
		
		System.out.printf("\n\nName           ID");
		
		// Prints each Student name and ID in StudentRoster in two columns.
		for(Student s : studentRoster) {
			System.out.printf("\n%-15s %-15s",s.getName(), s.getId());
		}
		
		
		
		
	}
}
