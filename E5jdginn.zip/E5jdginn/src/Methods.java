// E5, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;


public class Methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
				
		// Calls method to greet user with a welcoming message.
		printGreeting();
		
		
		//Initializes result to store returned integer value.
		int result;
		
		//Sends 5 and 2 as parameters for product method for two integers.
		result = Methods.product(5, 2); 
		System.out.println("\n*** Testing Product and return values ***");
		System.out.printf("The product of 5 and 2 is %d", result);
		
		//sends 2,3, and 5 as three parameters for product method.
		result = Methods.product(2, 3, 5);
		System.out.println("\n\n*** Testing Product method using 3 arguments, 2, 3, and 5 ***");
		System.out.printf("The product using three arguments - 2, 3, and 5 is %d", result);
		
		
		
		
		// Concatenates two strings and prints within quotes.
		System.out.println("\n\n*** Testing Concatenate and nested method calls ***");
		System.out.printf("The return value is \"%s\"", concatenate("Hello", "World") );
		
		
		
		//Initializes boolean for storage of returned value below.
		boolean numberFound = false;
		
		// Calls arrayContains method to check if 4 is present in array.
		System.out.println("\n\n\n*** Testing Array Search ***");
		System.out.println("Testing if the number 4 is present in the array...");
		numberFound = arrayContains(4);
		
		// If number is in the array, System prints so.
		if (numberFound == true)
			System.out.printf("Array contains the number 4");
		else
			System.out.printf("Array does not contain the number 4");
		
		
		// Calls arrayContains method to check if 50 is present in array.
		System.out.println("\n\nTesting if the number 50 is present in the array...");
		numberFound = arrayContains(50);
		
		// If number is in the array, System prints so.
		if (numberFound == true)
			System.out.printf("Array contains the number 50");
		else
			System.out.printf("Array does not contain the number 50");
		
		
		
		
		// Initializes quotient as a double and assigns returned value from divide method.
		// Prints result to fourth decimal for user.
		double quotient = 0.0000;
		quotient = divide(7,6);
		System.out.println("\n\n*** Testing Divide and return values ***");
		System.out.printf("The result of dividing 7 by 6 is %.4f", quotient);
		
		
		// Initializes number of times the loop within "calculateAverage" Method- loops for.
		int numberOfLoops = 0;
		
		// Requests number "n", and returns average from all numbers from n to 1- summed together.
		System.out.println("\n\n*** Testing Average Method ***");
		System.out.println("This method will calculate the average of all numbers from 1 to n.");
		System.out.printf("Enter n: ");
		numberOfLoops = Integer.parseInt(scanner.nextLine());
		
		System.out.printf("\nThe average of all numbers from 1 to %d is %.2f", numberOfLoops, calculateAverage(numberOfLoops) );
	
		scanner.close();
	}

	// Prints greeting to user.
	private static void printGreeting() {
		System.out.println("Hello");
	}
	
	
	// Returns product of two integers.
	private static int product(int number1, int number2) {
		
		int result = number1 * number2;
		
		return result;
	}
	
	// Returns two Strings combined together.
	private static String concatenate (String string1, String string2) {
		
		String combined = string1 + string2;
		
		return combined;
	}
	
	
	// Returns quotient of two integers.
	private static double divide (int number1, int number2) {
		
		double quotient = 0.0;
		
		quotient = (double) number1 / number2;
				
		return quotient;		
	}
	
	// Initializes array to search with in following arrays.
	static int[] listOfNumbers = {1, 2, 3, 4, 5};
	
	
	// Finds if specified integer is in listOfNumbers array.
	private static boolean arrayContains (int number) {
		
		boolean found = false;
		
		for (int i = 0; i < listOfNumbers.length; i++) {
			
			if (number == listOfNumbers[i]) 
				found = true;
		
		} //End for
		
		return found;
		
	}
	
	
	// Returns product of 3 integers.
	private static int product (int number1, int number2, int number3) {
		
		int result = number1 * number2 * number3;
		
		return result;
	}
	
	// Returns average of all numbers 1 to user inputed "number".
	private static double calculateAverage (int number) {
		
		int sum = 0;
		for (int i = 1; i <= number; i++) {
			sum = sum + i;
		}
		double average = (float) sum / number;
		
		return average;
	}
	
}
