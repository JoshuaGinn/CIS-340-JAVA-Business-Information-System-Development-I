// A4, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class ShoppingCart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
		
		// Initialize Counters for each category.
		float techCounter = 0;
		float groceryCounter = 0;
		float officeCounter = 0;
		float otherCounter = 0;
		
		// Initialize Running totals per department
		float techSum = 0;
		float grocerySum = 0;
		float officeSum = 0;
		float otherSum = 0;
		
		// Initialize Averages variable for later calculations.
		float techAverage = 0;
		float groceryAverage = 0;
		float officeAverage = 0;
		float otherAverage = 0;
		
		// Initializes an array per each piece of info collected (3)
		String[] productName;
		String[] productCategory;
		float price[];
		
		// Defines the number of columns per array.
		productName = new String[5];
		productCategory = new String[5];
		price = new float[5];
		
		//Introduces function of program to user/ Welcome message.
		System.out.println("\t\t\tShopping Cart\n\n");
		System.out.println("This program maintains a list of products (name, category, price). It will calculate average dollars spent per category for you.\n");
		
		//Prompts user to enter Name, Category, and price of 5 products.
		for (int i=0; i<productName.length; i++)
		{
			System.out.printf("\nEnter product name: ");
			productName[i] = scanner.nextLine();
			
			System.out.printf("Enter product category (Tech/Grocery/Office): ");
			productCategory[i] = scanner.nextLine();
			
			System.out.printf("Enter product price: ");
			price[i] = Float.parseFloat(scanner.nextLine());
			
		}//End For
		
		
		// Categorizes based on productCategory and adds to running department totals.
		for (int i=0; i<productName.length; i++)
		{
			if (productCategory[i].equalsIgnoreCase("Tech"))
			{
				techSum = techSum + price[i];
			}
			else if (productCategory[i].equalsIgnoreCase("Grocery"))
			{
				grocerySum = grocerySum + price[i];
			}
			else if (productCategory[i].equalsIgnoreCase("Office"))
			{
				officeSum = officeSum + price[i];
			}
			else			
			{
				otherSum = otherSum + price[i];
			}
			
		}//End For
		
		
		// List the Tech products based on productCategory value.
		System.out.println("\n\nTECH PRODUCTS");
		for (int i=0; i<productName.length; i++)
		{
			if (productCategory[i].equalsIgnoreCase("Tech"))
			{
				System.out.println(productName[i]);
				techCounter++;
			}
		}//End For
		//Calculates Average spent in TECH department.
		techAverage = (float) techSum /techCounter;
		System.out.printf("Average dollars spent: %.2f\n\n", techAverage);
		
		
		
		
		
		// List the Grocery products based on productCategory value.
		System.out.println("GROCERY PRODUCTS");
		for (int i=0; i<productName.length; i++)
		{
			if (productCategory[i].equalsIgnoreCase("Grocery"))
			{
				System.out.println(productName[i]);
				groceryCounter++;
			}
		}//End For
		//Calculates Average spent in GROCERY department.
		groceryAverage = (float) grocerySum / groceryCounter;
		System.out.printf("Average dollars spent: %.2f\n\n", groceryAverage);
		
		
		
		
		
		// List the office products based on productCategory value.
		System.out.println("OFFICE PRODUCTS");
		for (int i=0; i<productName.length; i++)
		{
			if (productCategory[i].equalsIgnoreCase("Office"))
			{
				System.out.println(productName[i]);
				officeCounter++;
			}
		}//End For
		//Calculates Average spent in OFFICE department.
		officeAverage = (float) officeSum / officeCounter;
		System.out.printf("Average dollars spent: %.2f\n\n", officeAverage);
		
		
		
		// Assigns remainder of products to Other category.
		System.out.println("OTHER");
		for (int i=0; i<productName.length; i++)
		{
			if (productCategory[i].equalsIgnoreCase("Tech")
				|| productCategory[i].equalsIgnoreCase("Grocery")
				|| productCategory[i].equalsIgnoreCase("Office"))
			{
				System.out.printf("");
			}
			else
			{	
				System.out.println(productName[i]);
				otherCounter++;
			}
		}//End For
		//Calculates Average spent in OTHER department.
		otherAverage = (float) otherSum / otherCounter;
		System.out.printf("Average dollars spent: %.2f\n\n", otherAverage);
		
		
		
		System.out.printf("Press Enter to Exit..");
		
		// Enter key will close program.
		int status = 0;
		String exit;
		exit = scanner.nextLine();
		System.out.printf(""+ exit);
		System.exit(status);
		
		
		scanner.close();
	}

}
