// E7, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class References {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Declares and initializes names array.
		String[] names;
		names = new String[5];
		
		System.out.println("**** Passing a Reference By-Value - Reading 5 Names ****\n\n");
		
		System.out.println("Putting values inside stringArray parameter");
		readStudentNames(names); //// reads and stores 5 names
		
		System.out.println("\nThe contents of nameArray are:");
		// reads the five names on seperate lines
		for (int i = 0; i <names.length; i++) {
			System.out.println(names[i]);
		} // End for
		
	}
	
	private static void readStudentNames(String[] stringArray) {
		
		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
		
		// reads and stores 5 names
		for (int i = 0; i < stringArray.length; i++) {
			System.out.printf("Enter name %d: ", i+1);
			stringArray[i] = scanner.nextLine();
		} // End for
		
		scanner.close();
	}
}

	

