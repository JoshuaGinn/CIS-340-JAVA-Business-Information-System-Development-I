// A1, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class TaxCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		
		//Initialize user input variables.
		double grossIncome = 0.00;
		String statusCode = "";		
		double deduction = 0.00;
		
		
		//Introduction to tax calculator.
		System.out.println("\t\t\tIncome Tax Calculator\n\n");
		System.out.println("This program will calculate you income tax.\n");
		
		//Requests for users gross income.
		System.out.printf("What is your gross income? ");
		grossIncome = Double.parseDouble(scanner.nextLine());
		
		
		//Displays all options for filing methods and corresponding abbreviations.
		System.out.println("\nFILING STATUS.");
		System.out.println("Single - SG");
		System.out.println("Married Joint - MJ");
		System.out.println("Married Separately - MS");
		System.out.println("Head of Household - HH");
		
		System.out.printf("\nEnter the two letter code corresponding with your status: ");
		statusCode = scanner.nextLine();
		
		// evaluates statusCode variable and assigns corresponding deduction amount.
		switch (statusCode) {	
		case "SG":
			deduction = 5950.00;
			break;
		case "MJ":
			deduction = 11900.00;
			break;
		case "MS":
			deduction = 5950.00;
			break;
		case "HH":
			deduction = 8700.00;
			break;
		default:
			deduction = 0.00;
			System.out.printf("Filing status entered incorrectly, deduction calculated at $0.");
			break;
		}
		
		//Initialize different tax amounts.
		double netIncome = grossIncome - deduction;
		double federalTax = 0.00;
		double stateTax = netIncome * 0.025;
		
		//Restates users gross income.
		System.out.printf("\nYour stated income was $%.2f.\n", grossIncome);	
			
		
		//Calculates federal tax amount from netIncome amount.
		if (netIncome < 30000)
		{
			federalTax = netIncome * .00;
		}
		else if (netIncome >= 30000 && netIncome < 60000)
		{
			federalTax = netIncome * .10;
		}
		else if (netIncome >= 60000 && netIncome < 100000)
		{
			federalTax = netIncome * .20;
		}
		else if (netIncome >= 100000 && netIncome < 250000)
		{
			federalTax = netIncome * .30;
		}
		else if (netIncome >= 25000)
		{
			federalTax = netIncome * .40;
		}
		
		
		//Sums both state and federal tax, and prints final tax liability to user.
		double incomeTax = federalTax + stateTax;
		System.out.printf("Your final tax liability is $%.2f.\n", incomeTax);
		
		
		scanner.close();
		
	}

}
