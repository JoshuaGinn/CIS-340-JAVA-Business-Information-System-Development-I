// E0, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String userName = "";
		
		System.out.println("Hello World");	
		System.out.print("What's your name? ");
		
		Scanner scanner = new Scanner(System.in);
		
		userName = scanner.nextLine();
		System.out.println("Hi " + userName + ". See you around!");
		
		scanner.close();	
	}

}
