// E4, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class Scores {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
		
		//Initialize parallel arrays and array within an array.
		int[] scores;
		int[][] extraCredit;
		String[] names;
		
		// Used in calculation of extra credit assignments average.
		int counter = 0;
		double average;
		int numberOfAssignments = 0;
		int sumOfExtraCreditScores = 0;
		
		// Creates parallel arrays for names of student and test score.
		names = new String[3];
		scores = new int[3];
		
		// Prompts user to insert names of students of grades being collected.
		System.out.println("\t\t\tStudent Grade System\n");
		System.out.println("This program will store student grades and look them up for you.\n");
		System.out.println("************************************");
		System.out.println("Enter names. One name per line.");
		System.out.println("************************************\n");
		
		
		// Loops  3 times to collect name of each student.
		for (int i =0; i < names.length; i++)
		{
			System.out.printf("Enter name: ");
			names[i] = scanner.nextLine();
		}

		
		// Prompts user to enter 3 scores and stores them parellel to the names array.
		System.out.println("\n\n");
		System.out.println("************************************");
		System.out.println("Enter Test scores. One score per line.");
		System.out.println("************************************\n");
		
		
		// Displays each name as the score is requested from user.
		for (int i =0; i < scores.length; i++)
		{	
			System.out.printf("Enter score for %s: ", names[i]);
			scores[i] = Integer.parseInt(scanner.nextLine());	
		}
		
		
		// Prints contents of name and scores arrays, to display all inputs back to user.
		System.out.println("\n\n\n");	
		System.out.printf("You entered the following data:\n\n");
		System.out.printf("Name		Score\n");
		
		
		// Loops 3 times, printing the corresponding score for each student.
		for (int i =0; i < names.length; i++)
		{
			System.out.printf("%-18s %2d\n",names[i], scores[i]);
		}
		
		
		//Formatting
		System.out.printf("\n\n");
		
		// Declares three columns for the array.
		extraCredit = new int[3][];
		
		
		/* Request number of scores for each student, then collects each score amount
		 for later calculations */
		for (int i=0; i < extraCredit.length; i++ )
		{
			System.out.printf("\nHow many extra credit scores for %s? ", names[i]);
			numberOfAssignments = Integer.parseInt(scanner.nextLine());
			
			extraCredit[i] = new int[numberOfAssignments];
			
			System.out.printf("\nEnter extra credit scores for %s\n", names[i]);
			for (int j=0; j < extraCredit[i].length; j++ )
			{
				System.out.printf("Score %s: ", j+1);
				extraCredit[i][j] = Integer.parseInt(scanner.nextLine());
				
				counter ++;
				sumOfExtraCreditScores = sumOfExtraCreditScores + extraCredit[i][j];
			}
			
			
		}
		
		// Displays number of scores collected.
		System.out.printf("\nThere were %s extra credit scores.", counter);
		
		//Forces float data type then displays average to the user.
		average = (float) sumOfExtraCreditScores/counter;
		System.out.printf("\nThe extra credit average is %.2f", average);
		
		scanner.close();
	}

}
