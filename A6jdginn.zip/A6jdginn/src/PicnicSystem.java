// A6, Joshua Ginn, jdginn, CIS340 Online


public class PicnicSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		PicnicSystem myPicnicSystem = new PicnicSystem();
		
		myPicnicSystem.makeFruitBaskets();
	}

	private void makeFruitBaskets() {
		FruitBasket basket1;
		FruitBasket basket2;
		
		basket1 = new FruitBasket();
		basket2 = new FruitBasket();
		
		basket1.setBasketName("Weekend");  
		basket2.setBasketName("Weekday");
		
		basket1.makeFruits();
		basket2.makeFruits();
		
		basket1.eatFruits();
		basket2.eatFruits();
	}
	
	
}
