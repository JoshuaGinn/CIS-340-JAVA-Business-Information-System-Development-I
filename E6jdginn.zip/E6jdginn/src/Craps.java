// E6, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;
import java.util.Random;

public class Craps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
		
		// Prompts user to press enter to receive two random numbers.
		System.out.println("\t\t\t Craps Die Roll\n");
		System.out.println("Press Enter to roll a pair of dice...");
		String moreInput = scanner.nextLine();
		
		// Prints the numbers to the console, then loops until any character is entered.
		do {
			System.out.printf("Rolling Die.... %s\n", numberToText(generateRandomNumber()));
			System.out.printf("Rolling Die.... %s\n", numberToText(generateRandomNumber()));
			
			System.out.printf("\nType x to exit or press Enter to roll again...");
			moreInput = scanner.nextLine();

			// If enter is not pressed (Any other character, System exits.
			if (moreInput != "")
				System.exit(0);

		} while (moreInput == "");
		
		// Closes scanner
		scanner.close();
		
	}

	private static String numberToText(int number) {

		
		String numberText = "";
		
		// Returns the integer entered as a String data type. (1 = ONE)
		switch (number) {
		case 1:
			numberText = "ONE";
			break;
		case 2:
			numberText = "TWO";
			break;
		case 3:
			numberText = "THREE";
			break;
		case 4:
			numberText = "FOUR";
			break;
		case 5:
			numberText = "FIVE";
			break;
		case 6:
			numberText = "SIX";
			break;
		} //End Switch
		
		return numberText;
	}//End Number To Text Method.
	
	
	// Returns a number 1-6 to the console.
	private static int generateRandomNumber() {
		Random randomGenerator = new Random();
		int randomNumber = randomGenerator.nextInt(6);
		randomNumber ++;
		return randomNumber;
	}
}
