// A7, Joshua Ginn, jdginn, CIS340 Online

import java.util.ArrayList;

public class Book {

	private int year;
	private String title;
	
	
	// No argument constructor for new Book
	public Book() {
		Book tmpBook = new Book();
		
	}
	
	//Assigns parameters as title and year for book class
	public Book(String title, int year) {
		
	this.year = year;
					
	this.title = title;

		
	}
	
	
	// Get and Set Title name.
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
	// Get year method to return Year.
	public int getYear() {
		return year;
	}
	
	
	// Set year Method with constraint that published year must be between 1100 and 2017.
	// any int out of range will assign year as 1900 for default.
	public void setYear(int year) {
		
		
		// Allows only years between defined years to be assigned
		if (year < 1100 && year > 2017) {
		
			this.year = year;
		}
		
		else {
			this.year = 1990;
		}
	
	}
	
	
	
	
}
