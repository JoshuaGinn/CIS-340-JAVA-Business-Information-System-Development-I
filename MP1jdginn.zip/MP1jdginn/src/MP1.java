// MP1, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class MP1 {

	
	
	//Imports scanner tool
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Declares variables related to storing names and scores.
		String[] names = new String[3];
		
		double classSum = 0;
		double quizSum = 0;
		
		int studentCounter = 1;
		
		// Prompts user to input number of scores and declares value as ScoreslList array length.
		System.out.printf("How many scores per student? ");
		int scoresPerStudent = Integer.parseInt(scanner.nextLine());
		double[][] scoresList = new double[3][scoresPerStudent];
		
		
		
		
		System.out.println();
		
		
		// Prompts user to insert 3 names, stores in names array
		//Inner for: Reads and stores same number of quizzes as scoresList array length.
		int userContinue = 0;
		for (int i = 0; i < names.length; i++) {
			
			
			// If statement with "userContinue" used to get past issue with scanner working correctly.
			if (userContinue == 5) {
			String notUsed = scanner.nextLine(); // Used to take in extra "enter" left from nextDouble scanner below.
			}
			
			userContinue = 5;
			System.out.printf("Enter name for student %d: ", studentCounter);
			names[i] = scanner.nextLine();
			studentCounter++;
			
			System.out.println("\nEntering scores for " + names[i].toUpperCase());
			
			for (int j = 0; j < scoresList[i].length; j++) {
				
				System.out.printf("Quiz %d: ", j+1);
				scoresList[i][j] = scanner.nextDouble();
				
			}
			System.out.println("");
		}
		
		//Some issues concerning the scanner caused me to need to implement counters
		// to skip the first scanner only.  If statement with "userContinue"
		userContinue = 5;
		
		
		// Menu is displayed repetively as long as userContinue is not 9 with do- while staments.
		do {
			
			// Resets Sum counters to zero.
			classSum = 0;
			quizSum = 0;
			
			
			// Displays user menu
			System.out.println("\n\n\n\n");
			System.out.println("\t\t\tMenu");
			System.out.println("1. Class Average");
			System.out.println("2. Student Average");
			System.out.println("3. Quiz Average\n");
			System.out.printf("Enter choice number, or 9 to exit: ");
			
			// If statement with "userContinue" used to get past issue with scanner working correctly.
			if (userContinue == 5) {
			String notUsed = scanner.nextLine(); // Used to take in extra "enter" left from nextDouble scanner below.
			}
			
			// Collects user input and stores as int
			userContinue = Integer.parseInt(scanner.nextLine());
			
			// Declares ints; Sum counters to zero.
			int classAverageCounter = 0;
			int studentAverageCounter = 0;
			int quizAverageCounter = 0;
			
			
			// Methods have not been my strong suite. Simuating method calling with switch in order to 
			// have something tangible to turn in that completes the objective.
			switch (userContinue) {
			// caculatesClassAverage();
			case 1: 
				// Loops through 3 names. Inner for Collects value from each name+ score combonation
				for (int i = 0; i < names.length; i++) {
				
					for (int j = 0; j < scoresList[i].length; j++) {
						classSum = classSum + scoresList[i][j];
						classAverageCounter++;
					}
				}	
				//Prints average of all name+score combinations to console.
				System.out.printf("\nClass average for all quizzes is " + classSum/classAverageCounter);
					
			break;
			
			// caculatesStudentAverage();
			case 2: 
				
				// Prompts user to input student name they would like the average score displayed for.
				System.out.println("\nCalculating average by student.\n");
				System.out.printf("Enter student name: ");
				String userChoice = scanner.nextLine();
				
				// Loops through names array and IF userChoice is equal to a name,
				//Inner for loop collects each score from that name only. 
				for (int i = 0; i < names.length; i++) {
				
					if (userChoice.equals(names[i])) {
					
						System.out.printf("%s's scores are:", names[i]);
						
							for (int j = 0; j < scoresList[i].length; j++) {
								System.out.print(" " + scoresList[i][j]);
								classSum = classSum + scoresList[i][j];
								studentAverageCounter++;
							}
						System.out.println();
						
						//Prints students name and average to the console.
						System.out.printf("%s's average is " + (classSum/studentAverageCounter), names[i]);	
					}		
				}
				// If the if statement above is never true- Student not found is displayed.
				if (classSum == 0) {
					System.out.println("\nStudent not found.");
				}
				//System.out.println();
				//System.out.println("%s's average is ") + (classSum/studentAverageCounter), names[i]);
			break; 
			
			// caculatesQuizAverage();
			case 3: 
				
				// Prompts user to calculate average by quiz number. Inputting quiz number.
				System.out.println("\nCalculating average by Quiz Number");
				System.out.printf("Enter Quiz number: ");
				int quizNumber = Integer.parseInt(scanner.nextLine());
				
				
				// Loops through all scores, and those in array position -1 of user input are 
				// stored for later use.
				for (int i = 0; i < names.length; i++) {
					
						for (int j = 0; j < scoresList[i].length; j++) {
				
							if ((quizNumber-1) == j) {
								quizSum = quizSum + scoresList[i][j];
								quizAverageCounter++;
							}
						}
					}		
				// Prints Quiz number and corresponding average to console.		
				double quizAverage = quizSum/quizAverageCounter;
				
				System.out.printf("\nQuiz " + quizNumber + " average is "  + quizAverage);
			break;
			
			// any other value will return user to Menu.
			default:
				break;
			}
		// If user selects 9 from menu, application stops.	
		} while (userContinue != 9);
		}
	}
		
	




