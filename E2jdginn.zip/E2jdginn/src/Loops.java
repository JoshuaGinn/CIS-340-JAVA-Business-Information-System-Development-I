// E2, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int asteriskCount = 0;
		
		// Create a scanner object to receive input
		Scanner scanner = new Scanner(System.in);
		
		// Receives input for asteriskCount to be printed back onto the console.
		System.out.println("\t\t\tPart 1. Basics");
		System.out.println("I can build you a line of astericks.");
		System.out.printf("How many astericks do you want? ");
		asteriskCount = Integer.parseInt(scanner.nextLine());	
		System.out.println();
		
		//Prints number of "*" entered using while statement.
		System.out.println("Printing a line of asterisks using a while loop");
		int counter = 0;
		while (counter < asteriskCount)
		{
			System.out.printf("*", counter);
			counter++;
		} //end while
		
		
		System.out.println();
		System.out.println();
		System.out.println("Printing a line of asterisks using a for loop");
		
		
		////Prints number of "*" entered using for loop.
		for (int i=0 ; i < asteriskCount ; i++ )
		{
			System.out.print("*");
		} //end for
		
		System.out.println();
		System.out.println();
		System.out.println("List of numbers from 1 to 5");
		
		
		// Prints numbers 1 through 5.
		for (int i=1 ; i < 6 ; i++)
		{
			System.out.printf(i + " ");
		} //end for
		
		
		System.out.println();
		System.out.println();
		
		// Loops 11 times, counting up from 0 in multiples of 5.
		System.out.println("List of multiples of 5 from 5 to 50");
		for (int i=0 ; i < 51 ; i+=5 )
		{
			System.out.printf(i + " ");
		} //end for
		
		System.out.println();
		System.out.println();
		
		
		//
		System.out.println("Multiplication Table for 2");
		for (int i=1 ; i < 13 ; i++ )
		{
			System.out.printf("2 * %2d = %2d\n", i, i*2);
		} //end for
		
		
		
		// Prompts users to enter numbers to be averaged, and exists as "x" is entered.
		System.out.println("\n\t\t\tPart 2. Logic");
		System.out.println("\nAverage Demo using Do Loop");
		System.out.println("\nCalculates an average of all numbers entered");
		System.out.println(" Enter \"x\" when finished entering numbers.");
		
		
		// Defines variables type as well as starting values.
		double average = 0.0;
		String input = "";
		int countOfInput = 0;
		int number = 0;
		int total = 0;
		
		
		// Prompts user to input number and assigns as input
		do {
			System.out.print("Enter number: ");
			input = scanner.nextLine();
			
			//Adds number to (running) total and adds one to the count
			//of input to be used as a denominator.
			if ( ! input.equalsIgnoreCase("X")) {
				number = Integer.parseInt(input);
				
				countOfInput++;
				
				total = total + number; 
			}
		}while (! input.equalsIgnoreCase("x"));
		
		
		// Calculates average and prints to console
		average = (double) total / countOfInput;
		System.out.printf("The average of all numbers is %.2f\n\n\n", average);
		
		
		// Prompts user that a while statement is used
		// to find average of numbers entered.
		System.out.println("Average Demo using While loop");
		System.out.println("\nCalculates an average of all numbers entered");
		System.out.println(" Enter \"x\" when finished entering numbers.");
	
		
		// Defines variables as starting values.
		input = "0";
		average = 0.0;
		number = 0;
		total = 0;
		countOfInput = 0;
		
		// Will loop until input variable is "x"
		while (input == "0")
		{
			System.out.printf("Enter number: ");
			input = scanner.nextLine();
			
			//Adds number to (running) total and adds one to the count
			//of input to be used as a denominator.
			if ( ! input.equalsIgnoreCase("X")) {
				number = Integer.parseInt(input);
						
				countOfInput++;
				
				total = total + number;
				
				// After input has been converted into an int, it is reset to zero
				// prior to next "Enter Number" prompt.
				input = "0";
			}
			
		}
		
		
		// Calculates average and prints to console
		average = (double) total / countOfInput;
		System.out.printf("The average of all numbers is %.2f\n\n", average);
		
		
		//For ten loops value of i is printed as "*".
		//Forms an up pointed arrow.
		for (int i = 0; i < 10 ; i++) {
			
			for (int j = 0; j < i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		
		
		// For ten loops, Number of i is printed as "*"
		//Forms an downPointed arrow.
		for (int i = 10; i > 0 ; i--) {
			
			for (int j = 0; j < i; j++) {
				 
				//Unable to use %10d placeholder to format :/
				System.out.printf("*");
			}
			System.out.println();
		}
		
		//Closes Scanner
		scanner.close();
	}
	
}



