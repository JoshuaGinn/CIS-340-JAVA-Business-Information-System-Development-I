// A6, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class FruitBasket {

	Scanner scanner = new Scanner(System.in);
	
	// Declares and initialzes apple and banana of type.
	private Apple apple;
	private Banana banana;
	private String basketName;
	 
	 // get and set basketName returns/declares this.basketName.
	public String getBasketName() {
		return basketName;
	}
	 
	public void setBasketName (String basketName ) {
	 
		this.basketName = basketName;
	}
	 
	
	// Passes fruits radius and length accordingly to new objects.
	public void makeFruits() {
		 apple = new Apple(1.5);
		 banana = new Banana(3.5);
		 
		 apple.setPeelThickness(1);
		 banana.setPeelThickness(4);
	}
	 
	//Prompts user to input percentage of each fruit they would like to eat. 
	// Each input is passed directly to specified "fruit".eat()
	public void eatFruits() {
		 
		 double amountToEat;
		 
		 System.out.printf("\t\t***%s***", basketName.toUpperCase());
		 System.out.printf("\nYou have an apple and a banana in your %s basket.\n", basketName);
		 
		 System.out.printf("What percent of the apple would you like to eat? ");
		 amountToEat = Double.parseDouble(scanner.nextLine());
		 apple.eat(amountToEat);
		 
		 System.out.printf("What percent of the banana would you like to eat? ");
		 amountToEat = Double.parseDouble(scanner.nextLine());
		 banana.eat(amountToEat);
		 
		 //Prints amount of fruit left to two decimal places.
		 System.out.printf("\nYou have %.2f of your apple and %.2f of your banana left in your %s basket.\n", apple.getPercentLeft(), banana.getPercentLeft(), basketName);
	 }
}
