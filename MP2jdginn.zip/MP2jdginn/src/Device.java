// MP2, Joshua Ginn, jdginn, CIS340 Online


public class Device {

	
	//Stores Device Stock Keeping Unit, Name, and availability.
	private String sku;
	private String name;
	private boolean available;
	
	
	//Assigns parameters as title and year for book class
	public Device(String sku, String name) {
		this.sku = sku;					
		this.name = name;
		this.available = true;	
	}
	
	// Returns SKU number
	public String getSku() {
		return sku;
	}
	// Assigns sku var
	public void setSku(String sku) {
		this.sku = sku;
	}
	
	// getter for device name
	public String getName() {
		return name;
	}
	// setter for device name
	public void setName(String name) {
		this.name = name;
	}
	
	
	// getter for available. true and false correlate with string returned.
	public String printAvailable() {
		String deviceAvailability;
		if (available==true)
			 deviceAvailability = ("Available");
		else
			deviceAvailability = ("Checked Out");
		return deviceAvailability;
		
	}
	
	
	// getter/Setter for boolean "available".
	public boolean getAvailable() {
		return available;
		
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}
		
		
	// Prints variables of Device object including availability.
	public void printInformationTitle() {
		System.out.printf("%-9s %-35s %s\n", getSku(),getName(), printAvailable());
	}
	
	// Prints variables of Device object excluding availability. - Use in Check in/check out.
	public void printInformation() {
		System.out.printf("%-9s %-35s\n", getSku(),getName());
	}
}
	


