// A2, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class MilesCalculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String destination = "";
		int mileage = 0; 
		int status = 0;
		double pointsEarned = 0.00;
		
		
		//Imports scanner tool
		Scanner scanner = new Scanner(System.in);
			
		// Displays program name and description.
		System.out.println("\t\t\t\tMiles Calulator\n\n");
		System.out.println("This program will calculate how many miles you will earn on your Phoenix Air flight\n");
					
		// Lists options of travel destinations and asks for users destination.
		System.out.println("DESTINATIONS");
		System.out.println("Los Angeles (LAX)");
		System.out.println("San Diego (SAN)");
		System.out.println("Las Vegas (LAS)\n");
	
		System.out.printf("Enter destination airport code: ");				
		destination = scanner.nextLine();
		
		
		//Assigns corresponding mileage to each destination.
		//If no destination is found, prompts user to exit program.
		switch (destination)
		{
		case "LAX":
			mileage = 369;
			break;
		case "SAN":
			mileage = 304;
			break;
		case "LAS":
			mileage = 255;
			break;
		default:
			System.out.println("\nPhoenix Air does not fly to " + destination + ". There will be zero points earned.");	
			System.out.printf("Press Enter to quit..");
			
			// Enter key will close program.
			String exit;
			exit = scanner.nextLine();
			System.out.printf(""+ exit);
			System.exit(status);
			break;
		}
						
		// Displays Status selections
		System.out.println("\nSTATUS");			
		System.out.println("1. Bronze");				
		System.out.println("2. Silver");					
		System.out.println("3. Gold");				
		System.out.println("4. Platinum\n");	
					

		// Receives user input and multiplies mileage by corresponding status multiplier
		System.out.printf("Enter frequent flyer staus option (1-4): ");
		status = Integer.parseInt(scanner.nextLine());		
					
		if ( status == 1)
		{
			pointsEarned = mileage;
		}
		else if ( status == 2) 
		{
			pointsEarned = (mileage * 1.25);
		}
		else if ( status == 3) 
		{
			pointsEarned = (mileage * 1.50);
		}
		else if ( status == 4) 
		{
			pointsEarned = (mileage * 2.00);
		}
		else  
		{
			pointsEarned = mileage;
		}			
		
		// Displays User with total miles earned flying to their destination.
		System.out.println("\nYou will earn " + pointsEarned + " miles flying from Phoenix to " + destination + "." );
		
		//Close scanner tool.
		scanner.close();
	}

}
