// E10, Joshua Ginn, jdginn, CIS340 Online

import java.util.Scanner;

public class CalorieCalculator {

	//New Scanner object for reading input.
	public static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Diplays application title
		System.out.println("\t\t\tRunning Calories Calculator\n\n");
		
		System.out.println("This application can calculate calories based on running mileage.\n");
		
		// Declares double variables as returned value from readInteger methods.
		double weight = readInteger("Enter runner weight (lbs): ");
		
		double minutes = readInteger("Enter minutes run: ");
		
		double seconds = readInteger("Enter seconds run: ");
		
		
		// calculates minutes and and seconds to represent total time.
		double totalTime = minutes + (seconds/60);
		
		// Declares Kilos as returned value from poundsToKilos methods. Converts lbs to kgs.
		double kilos = poundsToKilos(weight);
		
		
		//Displays total time ran, as well as total number for calories burnt.
		System.out.printf("\nIf you run %.0f minutes and %.0f seconds at 6mph, \nthe calories burned are approximately %.2f", minutes, seconds, caloriesSpentRunning(kilos, totalTime) );
		
	}

	// Declares global, final variables for calculating lbs to kg, and caloriesSpent.
	static final double CALORIE_COEFFICIENT = 0.167;
	static final double POUNDKG_COEFFICIENT = 0.453592;
	
	// Accepts pounds(double) and returns weight in Kilos.
	public static double poundsToKilos(double pounds) {
		
		double result = POUNDKG_COEFFICIENT * pounds;
		return result;
	}

	// Multiplies two parameters by Calorie Coefficient and returns total calories spent.
	public static double caloriesSpentRunning(double kilos, double totalTime) {
		
		double result = kilos * totalTime * CALORIE_COEFFICIENT;
		return result;
	}
	
	
	// Utilizes Try and Catch to give user three chances for appropriate input.
	public static int readInteger(String displayString) {
		
		int numberOfErrors = 0;
		int number = 0;
		boolean repeatInput= false;
		
		
		do {
			try {
				System.out.printf(displayString);
				number = Integer.parseInt(scanner.nextLine());
				repeatInput = false;
			}
		
		
		catch(NumberFormatException e) {
			if (numberOfErrors == 2) {
				System.out.printf("\nYou are having trouble entering data. Press Enter to exit.");
				String exit = scanner.nextLine();
				System.exit(0);
			} //End if
			
			System.out.println("\nInput must be a valid integer. Try again.\n");
			repeatInput = true;
			
			numberOfErrors++;
			
		} // End catch
		
		}while (repeatInput == true);
		
		return number;
		
		
		
		
	}
}
